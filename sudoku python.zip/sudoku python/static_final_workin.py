import tkinter as tk
from tkinter import messagebox

class SudokuGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Sudoku Puzzle")
        
        self.board = [
            [5, 3, 0, 0, 7, 0, 0, 0, 0],
            [6, 0, 0, 1, 9, 5, 0, 0, 0],
            [0, 9, 8, 0, 0, 0, 0, 6, 0],
            [8, 0, 0, 0, 6, 0, 0, 0, 3],
            [4, 0, 0, 8, 0, 3, 0, 0, 1],
            [7, 0, 0, 0, 2, 0, 0, 0, 6],
            [0, 6, 0, 0, 0, 0, 2, 8, 0],
            [0, 0, 0, 4, 1, 9, 0, 0, 5],
            [0, 0, 0, 0, 8, 0, 0, 7, 9]
        ]
        
        self.entries = [[None for _ in range(9)] for _ in range(9)]  # Entries on the GUI
        
        self.create_grid()
    
    def create_grid(self):
        for i in range(9):
            for j in range(9):
                entry = tk.Entry(self.root, width=2, font=('Arial', 30), justify='center')
                entry.grid(row=i, column=j)
                if self.board[i][j] != 0:
                    entry.insert(0, str(self.board[i][j]))
                    entry.config(state='disabled')  # Disable pre-filled cells
                self.entries[i][j] = entry
                entry.bind('<KeyRelease>', lambda event, i=i, j=j: self.validate_entry(event, i, j))
    
    def validate_entry(self, event, i, j):
        value = self.entries[i][j].get()
        if value:
            if not value.isdigit() or int(value) < 1 or int(value) > 9:
                messagebox.showerror("Error", "Please enter a valid number (1-9)")
                self.entries[i][j].delete(0, tk.END)
            else:
                self.board[i][j] = int(value)

        else:
            self.entries[i][j].delete(0, tk.END)
            self.board[i][j] = 0

        self.validate_board()
    
    def validate_board(self):
        for i in range(9):
            for j in range(9):
                if self.board[i][j] != 0:
                    for x in range(9):
                        if i != x and self.board[i][j] == self.board[x][j]:
                            messagebox.showerror("Error", "Duplicate number in column")
                            self.entries[i][j].delete(0, tk.END)
                            self.board[i][j] = 0
                            return
                        if j != x and self.board[i][j] == self.board[i][x]:
                            messagebox.showerror("Error", "Duplicate number in row")
                            self.entries[i][j].delete(0, tk.END)
                            self.board[i][j] = 0
                            return
                    row_start = (i // 3) * 3
                    col_start = (j // 3) * 3
                    for x in range(row_start, row_start + 3):
                        for y in range(col_start, col_start + 3):
                            if x != i and y != j and self.board[i][j] == self.board[x][y]:
                                messagebox.showerror("Error", "Duplicate number in 3x3 box")
                                self.entries[i][j].delete(0, tk.END)
                                self.board[i][j] = 0
                                return
    
if __name__ == "__main__":
    root = tk.Tk()
    app = SudokuGUI(root)
    root.mainloop()
